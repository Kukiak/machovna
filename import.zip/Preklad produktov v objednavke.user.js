// ==UserScript==
// @name         Preklad produktov v objednavke
// @namespace    http://tampermonkey.net/
// @version      1.8
// @description  Replaces product names with Slovak translations, using UTF-8 TextDecoder to handle diacritics properly
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const csvUrl = "https://api.allorigins.win/raw?url=https://github.com/Kukiak/machovna/raw/refs/heads/main/csv_utf.csv";

    async function fetchCsvAndReplace() {
        try {
            const response = await fetch(csvUrl);
            if (!response.ok) {
                throw new Error(`Failed to fetch the CSV file from URL: ${response.statusText}`);
            }

            // Use ArrayBuffer and TextDecoder for explicit UTF-8 decoding
            const arrayBuffer = await response.arrayBuffer();
            const csvText = new TextDecoder('utf-8').decode(arrayBuffer);
            const translations = parseCsv(csvText);
            replaceProductNames(translations);
        } catch (error) {
            console.error("Failed to fetch or decode the CSV file:", error);
        }
    }

    function parseCsv(csvText) {
        const lines = csvText.split("\n");
        const translations = {};
        lines.forEach(line => {
            const [code, translation] = line.split(";");
            if (code && translation) {
                translations[code.trim()] = translation.trim();
            }
        });
        return translations;
    }

    function replaceProductNames(translations) {
        const productElements = document.querySelectorAll("td.col-title.product-title");
        productElements.forEach(el => {
            const productCodeElement = Array.from(el.querySelectorAll("div")).find(div => div.textContent.includes("Kód:"));
            if (productCodeElement) {
                let productCode = productCodeElement.textContent.split(":")[1].trim();

                if (productCode.includes("-")) {
                    productCode = productCode.split("-")[0];
                }

                const translatedName = translations[productCode];
                if (translatedName) {
                    const productNameElement = el.querySelector("strong a");
                    if (productNameElement) {
                        productNameElement.textContent = translatedName;
                        console.log(`Replaced product name for code ${productCode}: ${translatedName}`);
                    }
                } else {
                    console.warn(`No translation found for product code: ${productCode}`);
                }
            }
        });
    }

    fetchCsvAndReplace();
})();
